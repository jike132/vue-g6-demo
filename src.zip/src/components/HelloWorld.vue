<template>
<div>
  <a href="#0">test </a>
  <a href="#1">test </a>
  <a href="#3">test </a>
  <div id="container">
    </div>
    </div>
</template>

<script>
import G6 from "@antv/g6"
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  mounted(){

// 模拟数据
const data = {
  nodes: [
    {
      x: 0,
      y: 0,
      label: "等级1",
      color: "#2196f3",
      type:"dom-node-1",
      meta: [
        { name: "任务1任务1任务1任务1任务1任务1", node: "zxj1.212" },
        { name: "任务2", node: "zxj1.212" },
        { name: "任务3", node: "zxj1.212" },
        { name: "任务4", node: "zxj1.212" },
        { name: "任务5", node: "zxj1.212" },
        { name: "任务6", node: "zxj1.212" },
        { name: "任务7", node: "zxj1.212" },
        { name: "任务8", node: "zxj1.212" },
        { name: "任务9", node: "zxj1.212" },
        { name: "任务10", node: "zxj1.212" },
        { name: "任务11", node: "zxj1.212" },
        { name: "任务12", node: "zxj1.212" },
        { name: "任务11", node: "zxj1.212" }
      ],
      id: "0"
    },
    {
      x: 0,
      y: 400,
      label: "等级1",
      color: "#2196f3",
       type: "dom-node-1",
      meta: [
        { name: "任务1任务1任务1任务1任务1任务1", node: "zxj1.212" },
        { name: "任务2", node: "zxj1.212" },
        { name: "任务3", node: "zxj1.212" },
        { name: "任务4", node: "zxj1.212" },
        { name: "任务5", node: "zxj1.212" },
        { name: "任务6", node: "zxj1.212" },
        { name: "任务7", node: "zxj1.212" },
        { name: "任务8", node: "zxj1.212" },
        { name: "任务9", node: "zxj1.212" },
        { name: "任务10", node: "zxj1.212" },
        { name: "任务11", node: "zxj1.212" },
        { name: "任务12", node: "zxj1.212" },
        { name: "任务11", node: "zxj1.212" }
      ],
      id: "1"

    },
    {
      x: 0,
      y: 900,
      label: "等级1",
       type: "dom-node-1",
      color: "#2196f3",
      meta: [
        { name: "任务1任务1任务1任务1任务1任务1", node: "zxj1.212" },
        { name: "任务2", node: "zxj1.212" },
        { name: "任务3", node: "zxj1.212" },
        { name: "任务4", node: "zxj1.212" },
        { name: "任务5", node: "zxj1.212" },
        { name: "任务6", node: "zxj1.212" },
        { name: "任务7", node: "zxj1.212" },
        { name: "任务8", node: "zxj1.212" },
        { name: "任务9", node: "zxj1.212" },
        { name: "任务10", node: "zxj1.212" },
        { name: "任务11", node: "zxj1.212" },
        { name: "任务12", node: "zxj1.212" },
        { name: "任务11", node: "zxj1.212" }
      ],
      id: "2"
    },
     {
      title: 'node1',
      error: true,
      nodeType: 'a',
      comboId:"combo1",
       type: 'card-node',
      id: 'node1',
      nodeLevel: 2,
      panels: [
        { title: '成功率', value: '11%' },
        { title: '耗时', value: '111' },
        { title: '错误数', value: '111' },
      ],
      x: 500,
      y: 50,
    },
    // {
    //   title: 'node2',
    //   error: false,
    //   comboId:"combo1",
    //   nodeType: 'b',
    //   id: 'node2',
    //   type: 'card-node',
    //   nodeLevel: 0,
    //   panels: [
    //     { title: '成功率', value: '11%' },
    //     { title: '耗时', value: '111' },
    //     { title: '错误数', value: '111' },
    //   ],
    //   x: 150,
    //   y: 120,
    // },
    // {
    //   title: 'node3',
    //   error: false,
    //   type: 'card-node',
    //   nodeType: 'a',
    //   id: 'node3',
    //   comboId:"combo1",
    //   nodeLevel: 3,
    //   panels: [
    //     { title: '成功率', value: '11%' },
    //     { title: '耗时', value: '111' },
    //     { title: '错误数', value: '111' },
    //   ],
    //   collapse: true,
    //   x: 250,
    //   y: 200,
    // },
    // {
    //   id:"test",
    //   x:300,
    //   y:0
    // }
  ],
  edges: [
    {
      id: "edge0",
      source: "0",
      target: "zxj1.212"
    },
    {
      id: "edge1",
      source: "1",
      target: "2"
    }
  ],
   combos: [
          { id: 'combo1',type:"rect"}

        ],
};
const ICON_MAP = {
  a: 'https://gw.alipayobjects.com/mdn/rms_8fd2eb/afts/img/A*0HC-SawWYUoAAAAAAAAAAABkARQnAQ',
  b: 'https://gw.alipayobjects.com/mdn/rms_8fd2eb/afts/img/A*sxK0RJ1UhNkAAAAAAAAAAABkARQnAQ',
};

G6.registerNode(
  'card-node',
  {
    drawShape: function drawShape(cfg, group) {
      const color = cfg.error ? '#F4664A' : '#30BF78';
      const r = 2;
      const shape = group.addShape('rect', {
        attrs: {
          x: 0,
          y: 0,
          width: 200,
          height: 0,
          stroke: color,
          radius: r,
        },
        name: 'main-box',
        draggable: true,
      });

      group.addShape('rect', {
        attrs: {
          x: 0,
          y: 0,
          width: 200,
          height: 25,
          fill: color,
          radius: [r, r, 0, 0],
        },
        name: 'title-box',
        draggable: true,
      });

      // left icon
      group.addShape('image', {
        attrs: {
          x: 4,
          y: 2,
          height: 16,
          width: 16,
          cursor: 'pointer',
          img: ICON_MAP[cfg.nodeType || 'app'],
        },
        name: 'node-icon',
      });

      // title text
      group.addShape('text', {
        attrs: {
          textBaseline: 'top',
          y: 2,
          x: 24,
          lineHeight: 20,
          text: cfg.title,
          fill: '#fff',
        },
        name: 'title',
      });
  // title text
  const btn=    group.addShape('text', {
        attrs: {
          textBaseline: 'top',
          y: 2,
          x: 150,
          lineHeight: 20,
           cursor: 'pointer',
          text: cfg.title,
          fill: '#0f0',
        },
        name: 'title',
      });
      group.on("click",(shape)=>{
  //       graph.updateItem(e.item, {style: {
  //   fill: 'blue',
  //   stroke:"blue",
  // }});
        console.log(shape)
      })
      // if (cfg.nodeLevel > 0) {
      //   group.addShape('marker', {
      //     attrs: {
      //       x: 184,
      //       y: 30,
      //       r: 6,
      //       cursor: 'pointer',
      //       symbol: cfg.collapse ? G6.Marker.expand : G6.Marker.collapse,
      //       stroke: '#666',
      //       lineWidth: 1,
      //     },
      //     name: 'collapse-icon',
      //   });
      // }

      // The content list
    /*  cfg.panels.forEach((item, index) => {
        // name text
        group.addShape('text', {
          attrs: {
            textBaseline: 'top',
            y: 25,
            x: 24 + index * 60,
            lineHeight: 20,
            text: item.title,
            fill: 'rgba(0,0,0, 0.4)',
          },
          name: `index-title-${index}`,
        });

        // value text
        group.addShape('text', {
          attrs: {
            textBaseline: 'top',
            y: 42,
            x: 24 + index * 60,
            lineHeight: 20,
            text: item.value,
            fill: '#595959',
          },
          name: `index-title-${index}`,
        });
      });*/
      this.bindEvent(group,btn);
      return shape;
    },
    bindEvent(group,btn){
btn.on("click",()=>{
console.log("test")
})
    }
  },
  'single-node',
);

// 定义 Dom 节点
G6.registerNode("dom-node-1", {
  draw: (cfg, group) => {

    const children = cfg.meta
      .map(
        (val) =>
          `<a style="flex: 1; border: 1px solid #2196f3; padding: 5px;margin:5px;font-size:12px;min-width:100px;max-width:200px" onclick="alert('${cfg.label}')">
        <p style="padding:0;margin:0;text-overflow:ellipsis;overflow: hidden;white-space: nowrap;">任务名称：${val.name}</p>
        <p style="padding:0;margin:0;">节点：${val.node}</p>
      </a>`
      )
      .join("");
    return group.addShape("dom", {
      attrs: {
        width: 500,
        height: 316,
        html: `<div style="border-left:solid blue 10px;text-align: left;" name="${cfg.id}">指标集市</div>
        <div style="border:1px solid #2196f3;border-radius:5px;" >
        <div style="text-align:center;background:#2196f3;font-size:18px;color:#fff;font-weight:bold;">${cfg.label}</div>
        <div style="display:flex;padding:10px; flex-wrap:wrap;" >
        ${children}
        </div>
        </div>
          `
      },
      draggable: true
    });
  },
  getAnchorPoints() {
    return [
      [0.5, 0],
      [0.5, 1]
    ];
  }
});

const width = document.body.clientWidth;
const height = window.innerHeight;
console.log(width,height)
const graph = new G6.Graph({
  container: "container",
  width,
  height,
  modes: {
    default: ["zoom-canvas", "drag-canvas"]
  },
  renderer: "svg", // 使用 Dom node 的时候需要使用 svg 的渲染形势
  // defaultNode: {
  //   type: "dom-node-1"
  // },
     groupByTypes: false,
        defaultCombo: {
          type: 'rect',
        },
  defaultEdge: {
    style: {
      endArrow: true,
      offset: 45,
      stroke: "#2196f3",
      lineWidth: 2
    }
  },
  fitCenter: true
});

graph.data(data);
graph.render();
graph.fitView();
graph.on("node:mouseenter",e=>{
  const node = graph.findById(e.item._cfg.id);
  console.log(node)
  let stroke="#fff"
   graph.setItemState(node, 'selected', false);
   const model = {
  id: e.item._cfg.id,
  style: {
    fill: 'blue',
    stroke:"blue",

  },
};
    graph.updateItem(e.item, {style: {
    fill: 'blue',
    stroke:"blue",

  }});
})

graph.on("node:mouseleave",e=>{
  const node = graph.findById(e.item._cfg.id);
  console.log(node)
  let stroke="#fff"
   graph.setItemState(node, 'selected', true);
   const model = {
  id: e.item._cfg.id,
  style: {
    fill: 'blue',
    stroke:"blue",

  },
};
    graph.updateItem(e.item, {style: {
    fill: 'yellow',
    stroke:"yellow",

  }});
})
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
a:hover{
background-color: blue;
}
</style>
