<template>
    <!-- <base-flow-editor/> -->
    <div id="container"/>
</template>

<script>
import G6 from '@antv/g6';
//import insertCss from 'insert-css';

// 我们用 insert-css 演示引入自定义样式
// 推荐将样式添加到自己的样式文件中
// 若拷贝官方代码，别忘了 npm install insert-css
// insertCss(`
//   .g6-component-tooltip {
//     background-color: rgba(255, 255, 255, 0.8);
//     padding: 0px 10px 24px 10px;
//     box-shadow: rgb(174, 174, 174) 0px 0px 10px;
//   }
// `);

import {renderMap} from '../assets/renderMap' //引入刚才封装的函数
export default{
  name:"Base",
 data(){
    return{
      data_map:{  //定义一个数组就是这组图中需要传入的数据，包含节点、分组及边的信息
      nodes: [
    {
      id: 'node1',
      label: 'node1',
      x: 100,
      y: 200,
      style: {
        fill: 'red',
        fontSize: 12,
        stroke:"yellow"
      },
      // 该节点可选的连接点集合，该点有两个可选的连接点
linkPoints: {
            left: true,
            right: true,
            size: 10,
            fill: 'black',
            lineWidth: 1,
            stroke: '#00ffaa',
          },

    },
    {
      id: 'node2',
      type:"diamond",
      label: 'node2',
      x: 300,
      y: 400,
      // 该节点可选的连接点集合，该点有两个可选的连接点
    linkPoints: {
            left: true,
            right: true,
            size: 10,
            fill: 'black',
            lineWidth: 1,
            stroke: '#00ffaa',
          },
      type: 'rect',
    },
         {
      title: 'node3',
      error: true,
      nodeType: 'a',
       type: 'card-node',
      id: 'node3',
      nodeLevel: 2,
        linkPoints: {
            left: true,
            right: true,
            size: 10,
            fill: 'black',
            lineWidth: 1,
            stroke: '#00ffaa',
          },
      panels: [
        { title: '成功率', value: '11%' },
        { title: '耗时', value: '111' },
        { title: '错误数', value: '111' },
      ],
      x: 500,
      y: 50,
    }
  ],
  edges: [
    {
      source: 'node1',
      target: 'node2',
      // 该边连入 source 点的第 0 个 anchorPoint，
      sourceAnchor: top,
      // 该边连入 target 点的第 0 个 anchorPoint，
      targetAnchor:top,
      style: {
        endArrow: true,
      },
    },
    {
      source: 'node2',
      target: 'node1',
      // 该边连入 source 点的第 1 个 anchorPoint，
      sourceAnchor: top,
      // 该边连入 source 点的第 1 个 anchorPoint，
      targetAnchor: top,
      style: {
        endArrow: true,
      },
    },
  ]
      //   nodes: [
      //     {
      // id: 'node1',
      // label: 'node1',
      // x: 100,
      // y: 200,
      // 该节点可选的连接点集合，该点有两个可选的连接点
     /* anchorPoints: [
        [0, 1],
        [0.5, 1],
      ],
      type: 'rect',*/
    //},
    //       { id: 'node2', label:'i系统',type:"diamond", comboId: 'combo1'},
    //       { id: 'node4', label:'i系统', comboId: 'combo4' },
    //       { id: 'node5',label:'i系统', comboId: 'combo4' },
    //  { id: 'node6',label:'i系统' ,type:"diamond",color:"red"},
    //       { id: 'node3', label:'数据工厂系统', comboId: 'combo3' },
    //       { id: 'node1', label:'数据工厂系统', comboId: 'combo1' },
 /*{
      title: 'node1',
      error: true,
      nodeType: 'a',
      type:"card-node",
      id: 'node7',
      nodeLevel: 2,*/
      // anchorPoints: [
      //   [0, 0.5], // 左侧中间
      //   [1, 0.5], // 右侧中间
      // ],
   /*   panels: [
        { title: '成功率', value: '11%' },
        { title: '耗时', value: '111' },
        { title: '错误数', value: '111' },
      ],
      x: 100,
      y: 100,
    }
        ],
        combos: [
          { id: 'combo2'},
          { id: 'combo3', label: 'Combo 3' },
          { id: 'combo1',parentId: 'combo2'},
          { id: 'combo4', label: 'Combo 4' ,parentId: 'combo2'},
        ],*/
      /*  edges: [
          {
            source: 'node3',
            target: 'node5',

          },
           {
            source: 'node3',
            target: 'node2',

          },
           {
            source: 'node3',
            target: 'node1',

          },
            {
            source: 'node1',
            target: 'node2',

          },
        ],*/
      },
      graph:{}, //定义一个全局graph
    }
  },
  mounted(){
const tooltip = new G6.Tooltip({
  offsetX: -150,
  offsetY: -150,
  // the types of items that allow the tooltip show up
  // 允许出现 tooltip 的 item 类型
  itemTypes: ['node'],
  // custom the tooltip's content
  // 自定义 tooltip 内容
  getContent: (e) => {
    const outDiv = document.createElement('div');
    outDiv.style.width = 'fit-content';
    //outDiv.style.padding = '0px 0px 20px 0px';
    outDiv.innerHTML = `
    <div class="arrow">
     <em></em><span></span>
    </div>
      <h4>Custom Content</h4>
      <ul>
        <li>Type: ${e.item.getType()}</li>
      </ul>
      <ul>
        <li>Label: ${e.item.getModel().label || e.item.getModel().id}</li>
      </ul>`;
    return outDiv;
  },
});
    this.graph = new G6.Graph({
        container: 'container',
        width:1000,
        height:500,
        fill:"green",
        stroke:"green",
        groupByTypes: false,
        // renderer: "svg",
  //       layout: {
  //  type: 'grid',
  //   begin: [ 0, 0 ],          // 可选，
  //   preventOverlap: true,     // 可选，必须配合 nodeSize
  //   preventOverlapPdding: 20, // 可选
  //   nodeSize: 30,             // 可选
  //   condense: false,          // 可选
  //   rows: 5,                  // 可选
  //   cols: 5,                  // 可选
  //   sortBy: 'degree'          // 可选
  // },
        defaultCombo: {
          type: 'cRect',
        },
        plugins:[tooltip],
        comboStateStyles: {
          dragenter: {
            lineWidth: 4,
            stroke: '#FE9797'
          }
        },
        defaultEdge: {
          type: 'line-arrow',
          style: {
            stroke: '#F6BD16',
            endArrow: {
              path: 'M 0,0 L 12,6 L 9,0 L 12,-6 Z',
              fill: '#F6BD16',
            },
          },
        },
        defaultNode: {
          type:"rect",
          size: [110,40],
          color:"blue",
           radius: 2,
           stateStyles:{
        radius:10
           },

          style: {
            fill: '#9EC9FF',
            stroke: '#5B8FF9',
            lineWidth: 3,
             radius: 2,
            position: 'left',
      background: {
        fill: '#ffffff',
        stroke: 'green',
        padding: [3, 2, 3, 2],
        radius: 2,
        lineWidth: 3,
      },
          },

          labelCfg: {
            style: {
              fill: '#afa',
              fontSize: 14,
            },
          },
          linkPoints: {
            left: true,
            right: true,
            top:true,
            bottom:true,
            size: 10,
            fill: 'yellow',
            lineWidth: 1,
            stroke: '#00ffaa',
          },
       },
        modes: {
          default: [
            'drag-combo',
            'drag-node',
            'drag-canvas'
          ]
        },
        fitCenter: true
    })
    renderMap(this.data_map,this.graph) //所有参数准备好之后，调用刚才封装的渲染函数去渲染组件
  }
  /*mounted(){

    // 注册模型卡片基类





const tooltip = new G6.Tooltip({
  offsetX: 10,
  offsetY: 10,
  // the types of items that allow the tooltip show up
  // 允许出现 tooltip 的 item 类型
  itemTypes: ['node'],
  // custom the tooltip's content
  // 自定义 tooltip 内容
  getContent: (e) => {
    const outDiv = document.createElement('div');
    outDiv.style.width = 'fit-content';
    //outDiv.style.padding = '0px 0px 20px 0px';
    outDiv.innerHTML = `
      <h4>Custom Content</h4>
      <ul>
        <li>Type: ${e.item.getType()}</li>
      </ul>
      <ul>
        <li>Label: ${e.item.getModel().label || e.item.getModel().id}</li>
      </ul>`;
    return outDiv;
  },
});
// 注册模型卡片基类
G6.registerNode('model-card', {
    draw(item) {
        const group = item.getGraphicGroup();
        const model = item.getModel();
        const width = 184;
        const height = 40;
        const x = -width / 2;
        const y = -height / 2;
        const borderRadius = 4;
        const keyShape = group.addShape('rect', {
            attrs: {
                x,
                y,
                width,
                height,
                radius: borderRadius,
                fill: 'white',
                stroke: '#CED4D9'
            }
        });
        // 左侧色条
        group.addShape('path', {
            attrs: {
                path: [
                    [ 'M', x, y + borderRadius ],
                    [ 'L', x, y + height - borderRadius ],
                    [ 'A', borderRadius, borderRadius, 0, 0, 0, x + borderRadius, y + height ],
                    [ 'L', x + borderRadius, y ],
                    [ 'A', borderRadius, borderRadius, 0, 0, 0, x, y + borderRadius ]
                ],
                fill: this.color_type
            }
        });
        // 类型 logo
        group.addShape('image', {
            attrs: {
                img: this.type_icon_url,
                x: x + 90,
                y: y + 12,
                width: 20,
                height: 16
            }
        });
        // 名称文本
        const label = model.label ? model.label : this.label;
        group.addShape('text', {
            attrs: {
                text: label,
                x: x + 11,
                y: y + 12,
                textAlign: 'start',
                textBaseline: 'top',
                fill: 'rgba(0,0,0,0.65)'
            }
        });
        // 状态 logo
        group.addShape('image', {
            attrs: {
                img: this.state_icon_url,
                x: x + 158,
                y: y + 12,
                width: 16,
                height: 16
            }
        });
        group.addGroup('custom');
        return keyShape;
    },
    // 设置锚点
    anchor: [
        [ 0.5, 0 ], // 上面边的中点
        [ 0.5, 1 ] // 下边边的中点
    ]
});
G6.registerNode('k-means', {
    label: 'k 均值聚类',
    color_type: '#1890FF',
    type_icon_url: 'https://gw.alipayobjects.com/zos/rmsportal/czNEJAmyDpclFaSucYWB.svg',
    state_icon_url: 'https://gw.alipayobjects.com/zos/rmsportal/MXXetJAxlqrbisIuZxDO.svg',
    // 设置锚点
    anchor: [
        [ 0.5, 0, {
            type: 'input'
        }], // 上面边的中点
        [ 0.5, 1, {
            type: 'output'
        }] // 下边边的中点
    ]
}, 'model-card');
const data =
    {
  nodes: [
    {
      id: 'node1',
     // type:"k-means",
      comboId: 'comboA' // node1 属于 comboA
    },
    {
      id: 'node2',
      comboId: 'comboB' // node2 属于 comboB
    },
    {
      id: 'node3', // node3 不属于任何 combo
    },
    // ...
  ],
  edges: [{
    source:"node1",
    target:"node2"
  }
    // ...
  ],
  combos: [
    { // 定义 comboA
      id: 'comboA',
      label: 'A',
      type:"rect",
      parentId: 'comboC'
    },
    { // 定义 comboB
      id: 'comboB',
      label: 'B',
      type:"rect",
      parentId: 'comboC'
    },
    { // 定义 comboC，这是一个空的 combo
      id: 'comboC',
      type:"rect",
      style:{
      width:200,
      height:400
      },
      label: 'C'
    },
    // ...
  ]
}
const graph = new G6.Graph({
  container: 'mountNode',
  fitView: 'cc',
  width: 500,
  height: 800,
  groupByTypes: false,
  defaultCombo: {
    // ... 其他属性
    style: {
      fill: '#ffffff',
      stroke: '#000000',
      lineWidth: 5,
      // ... 其他属性
       labelCfg: {
      position: 'center',
      offset: [10, 10, 10, 10],
      style: {
        fill: '#666',
      },
    },
    },
  },
});
graph.read(data);
 graph.on('node:click', ev => {
            this.selectedModel = ev.item.getModel();
            alert(this.selectedModel)
            console.log( this.selectedModel);
            //ev.data
          //  ev.item.edges[0].hide()
        });
//graph.update(data)
graph.on('node:mouseenter', (ev) => {
   this.selectedModel = ev.item.getModel();
        //    alert(this.selectedModel)
            console.log(this.selectedModel);
  graph.setItemState(ev.item, 'active', true);
});
// graph.on('node:mouseleave', (e) => {
//   graph.setItemState(e.item, 'active', false);
// });


  }
  */
}
</script>
<style >
.g6-component-tooltip{ width:300px; height:100px; border:1px solid white; position:relative; background-color:#FFF;}
.arrow{ position:absolute; width:40px; height:40px; bottom:-40px; left:100px; }
.arrow *{ display:block; border-width:20px; position:absolute; border-style:solid dashed dashed dashed; font-size:0; line-height:0; }
.arrow em{border-color:rgba(240,240,240,.5) transparent transparent;}
.arrow span{border-color:#FFF transparent transparent; top:-7px;}
  /* .g6-component-tooltip {
    border: 1px solid #e2e2e2;
    border-radius: 4px;
    font-size: 12px;
    color: #545454;
    background-color: black;

    border-radius: 8px;
    padding: 10px 8px;
    box-shadow: rgb(174, 174, 174) 0px 0px 10px;

  } */
</style>
