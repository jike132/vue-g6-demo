import G6 from '@antv/g6';
export function renderMap(data,graph){
  const collapseIcon = (x, y, r) => {
    return [
      ['M', x - r, y],
      ['a', r, r, 0, 1, 0, r * 2, 0],
      ['a', r, r, 0, 1, 0, -r * 2, 0],
      ['M', x - r + 4, y],
      ['L', x - r + 2 * r - 4, y],
    ];
  };
  const expandIcon = (x, y, r) => {
    return [
      ['M', x - r, y],
      ['a', r, r, 0, 1, 0, r * 2, 0],
      ['a', r, r, 0, 1, 0, -r * 2, 0],
      ['M', x - r + 4, y],
      ['L', x - r + 2 * r - 4, y],
      ['M', x - r + r, y - r + 4],
      ['L', x, y + r - 4],
    ];
  };

  G6.registerCombo('cRect', {
    drawShape: function drawShape(cfg, group) {
      const self = this;
      // Get the padding from the configuration
      cfg.padding = cfg.padding || [50, 20, 20, 20];
      // Get the shape's style, where the style.width and style.height correspond to the width and height in the figure of Illustration of Built-in Rect Combo
      const style = self.getShapeStyle(cfg);
      // Add a rect shape as the keyShape which is the same as the extended rect Combo
      const rect = group.addShape('rect', {
        attrs: {
          ...style,
          x: -style.width / 2 - (cfg.padding[3] - cfg.padding[1]) / 2,
          y: -style.height / 2 - (cfg.padding[0] - cfg.padding[2]) / 2,
          width: style.width,
          height: style.height,
        },
        draggable: true,
        name: 'combo-keyShape'
      });
      // group.addShape('image', {
      //   attrs: {
      //     ...style,
      //     img: "https://gw.alipayobjects.com/zos/rmsportal/czNEJAmyDpclFaSucYWB.svg",
      //     width: 20,
      //     height: 16
      // }
      // });
      group.addShape('text', {
        attrs: {
          ...style,
          x: cfg.style.width / 2 + cfg.padding[1],
          //   y: (cfg.padding[2] - cfg.padding[0]) / 2,
         text:"测试",
          width: 20,
          fill:"black",
          stroke:"black",
          height: 16
      }
      });
      // Add the circle on the right
      // group.addShape('marker', {
      //   attrs: {
      //     ...style,
      //     fill: '#fff',
      //     opacity: 1,
      //     // cfg.style.width and cfg.style.heigth correspond to the innerWidth and innerHeight in the figure of Illustration of Built-in Rect Combo
      //     x: cfg.style.width / 2 + cfg.padding[1],
      //     y: (cfg.padding[2] - cfg.padding[0]) / 2,
      //     r: 10,
      //     symbol: collapseIcon
      //   },
      //   draggable: true,
      //   name: 'combo-marker-shape'
      // });
      return rect;
    },
    // Define the updating logic of the right circle
    afterUpdate: function afterUpdate(cfg, combo) {
      const group = combo.get('group');
      // Find the circle shape in the graphics group of the Combo by name
      const marker = group.find(ele => ele.get('name') === 'combo-marker-shape');
      // Update the position of the right circle
      // marker.attr({
      //   // cfg.style.width and cfg.style.heigth correspond to the innerWidth and innerHeight in the figure of Illustration of Built-in Rect Combo
      //   x: cfg.style.width / 2 + cfg.padding[1],
      //   y: (cfg.padding[2] - cfg.padding[0]) / 2,
      //   // The property 'collapsed' in the combo data represents the collapsing state of the Combo
      //   // Update the symbol according to 'collapsed'
      //   symbol: cfg.collapsed ? expandIcon : collapseIcon
      // });
    }
  }, 'rect');
  G6.registerNode('k-means', {
    label: 'k 均值聚类',
    color_type: '#1890FF',
    type_icon_url: 'https://gw.alipayobjects.com/zos/rmsportal/czNEJAmyDpclFaSucYWB.svg',
    state_icon_url: 'https://gw.alipayobjects.com/zos/rmsportal/MXXetJAxlqrbisIuZxDO.svg',
    // 设置锚点
    anchor: [
     [ 0.5, 0, {
            type: 'input'
        }], // 上面边的中点
        [ 0.5, 1, {
            type: 'output'
        }] // 下边边的中点
    ]
}, 'model-card');
// 注册模型卡片基类
G6.registerNode('model-card', {
  draw(item) {
      const group = item.getGraphicGroup();
      const model = item.getModel();
      const width = 184;
      const height = 40;
      const x = -width / 2;
      const y = -height / 2;
      const borderRadius = 4;
      const keyShape = group.addShape('rect', {
          attrs: {
              x,
              y,
              width,
              height,
              radius: borderRadius,
              fill: 'white',
              stroke: '#CED4D9'
          }
      });
      // 左侧色条
      group.addShape('path', {
          attrs: {
              path: [
                  [ 'M', x, y + borderRadius ],
                  [ 'L', x, y + height - borderRadius ],
                  [ 'A', borderRadius, borderRadius, 0, 0, 0, x + borderRadius, y + height ],
                  [ 'L', x + borderRadius, y ],
                  [ 'A', borderRadius, borderRadius, 0, 0, 0, x, y + borderRadius ]
              ],
              fill: this.color_type
          }
      });
      // 类型 logo
      group.addShape('image', {
          attrs: {
              img: this.type_icon_url,
              x: x + 90,
              y: y + 12,
              width: 20,
              height: 16
          }
      });
      // 名称文本
      const label = model.label ? model.label : this.label;
      group.addShape('text', {
          attrs: {
              text: label,
              x: x + 11,
              y: y + 12,
              textAlign: 'start',
              textBaseline: 'top',
              fill: 'rgba(0,0,0,0.65)'
          }
      });
      // 状态 logo
      group.addShape('image', {
          attrs: {
              img: this.state_icon_url,
              x: x + 158,
              y: y + 12,
              width: 16,
              height: 16
          }
      });
      group.addGroup('custom');
      return keyShape;
  },
  // 设置锚点
  anchor: [
      [ 0.5, 0 ], // 上面边的中点
      [ 0.5, 1 ] // 下边边的中点
  ]
});
G6.registerNode(
  'diamond',
  {
    //... // 其他方法
    getAnchorPoints() {
      return [
        [0, 0.5], // 左侧中间
        [1, 0.5], // 右侧中间
      ];
    },
  },
  'circle',
);
const ICON_MAP = {
  a: 'https://gw.alipayobjects.com/mdn/rms_8fd2eb/afts/img/A*0HC-SawWYUoAAAAAAAAAAABkARQnAQ',
  b: 'https://gw.alipayobjects.com/mdn/rms_8fd2eb/afts/img/A*sxK0RJ1UhNkAAAAAAAAAAABkARQnAQ',
};

G6.registerNode(
  'card-node',
  {
    drawShape: function drawShape(cfg, group) {
      const color = cfg.error ? '#F4664A' : '#30BF78';
      const r = 2;
      const shape = group.addShape('rect', {
        attrs: {
          x: 0,
          y: 0,
          width: 200,
          height: 60,
          stroke: color,
          radius: r,
        },
        name: 'main-box',
        draggable: true,
      });

      group.addShape('rect', {
        attrs: {
          x: 0,
          y: 0,
          width: 200,
          height: 20,
          fill: color,
          radius: [r, r, 0, 0],
        },
        name: 'title-box',
        draggable: true,
      });

      // left icon
      group.addShape('image', {
        attrs: {
          x: 4,
          y: 2,
          height: 16,
          width: 16,
          cursor: 'pointer',
          img: ICON_MAP[cfg.nodeType || 'app'],
        },
        name: 'node-icon',
      });

      // title text
      group.addShape('text', {
        attrs: {
          textBaseline: 'top',
          y: 2,
          x: 24,
          lineHeight: 20,
          text: cfg.title,
          fill: '#fff',
        },
        name: 'title',
      });

      if (cfg.nodeLevel > 0) {
        group.addShape('marker', {
          attrs: {
            x: 184,
            y: 30,
            r: 6,
            cursor: 'pointer',
            symbol: cfg.collapse ? G6.Marker.expand : G6.Marker.collapse,
            stroke: '#666',
            lineWidth: 1,
          },
          name: 'collapse-icon',
        });
      }

      // The content list
      cfg.panels.forEach((item, index) => {
        // name text
        group.addShape('text', {
          attrs: {
            textBaseline: 'top',
            y: 25,
            x: 24 + index * 60,
            lineHeight: 20,
            text: item.title,
            fill: 'rgba(0,0,0, 0.4)',
          },
          name: `index-title-${index}`,
        });

        // value text
        group.addShape('text', {
          attrs: {
            textBaseline: 'top',
            y: 42,
            x: 24 + index * 60,
            lineHeight: 20,
            text: item.value,
            fill: '#595959',
          },
          name: `index-title-${index}`,
        });
      });
      return shape;
    },
  },
  'rect',
);

  G6.registerEdge(
    'line-arrow',
    {
      getPath(points) {
        const startPoint = points[0];
        const endPoint = points[1];
        return [
          ['M', startPoint.x, startPoint.y],
          ['L', endPoint.x / 3 + (2 / 3) * startPoint.x, startPoint.y],
          ['L', endPoint.x / 3 + (2 / 3) * startPoint.x, endPoint.y],
          ['L', endPoint.x, endPoint.y],
        ];
      },
      getShapeStyle(cfg) {
        const startPoint = cfg.startPoint;
        const endPoint = cfg.endPoint;
        const controlPoints = this.getControlPoints(cfg);
        let points = [startPoint]; // the start point
        // the control points
        if (controlPoints) {
          points = points.concat(controlPoints);
        }
        // the end point
        points.push(endPoint);
        const path = this.getPath(points);
        const style = Object.assign(
          {},
          G6.Global.defaultEdge.style,
          {
            stroke: '#BBB',
            lineWidth: 1,
            path,
          },
          cfg.style,
        );
        return style;
      },
    },
    'line',
  );

  const width = document.getElementById('container').scrollWidth;
  const height = (document.getElementById('container').scrollHeight || 500) - 20;

  graph.read(data);
  graph.fitView();
 // graph.render();

  // collapse/expand when click the marker
  graph.on('combo:click', e => {
    if (e.target.get('name') === 'combo-marker-shape') {
      // graph.collapseExpandCombo(e.item.getModel().id);
      graph.collapseExpandCombo(e.item);
      if (graph.get('layout')) graph.layout();
      else graph.refreshPositions();
    }
  });
  graph.on('node:mouseenter', (e) => {
    graph.setItemState(e.item, 'active', true);
  });
  graph.on('node:mouseleave', (e) => {
    graph.setItemState(e.item, 'active', false);
  });
  graph.on('combo:dragend', e => {
    graph.getCombos().forEach(combo => {
      graph.setItemState(combo, 'dragenter', false);
    })
  });
  graph.on('node:dragend', e => {
    graph.getCombos().forEach(combo => {
      graph.setItemState(combo, 'dragenter', false);
    })
  });

  graph.on('combo:dragenter', e => {
    graph.setItemState(e.item, 'dragenter', true);
  });
  graph.on('combo:dragleave', e => {
    graph.setItemState(e.item, 'dragenter', false);
  });
}
